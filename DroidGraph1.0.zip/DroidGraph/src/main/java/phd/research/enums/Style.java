package phd.research.enums;

/**
 * @author Jordan Doyle
 */
public enum Style {
    solid, dashed, dotted, bold, invisible, filled, diagonals, rounded
}
