package phd.research.enums;

/**
 * @author Jordan Doyle
 */
public enum State {
    created, started, resumed, paused, stopped, restarted, destroyed
}
