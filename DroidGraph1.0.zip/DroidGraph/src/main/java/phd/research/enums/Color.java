package phd.research.enums;

/**
 * @author Jordan Doyle
 */
public enum Color {
    red, orange, yellow, green, blue, purple, brown, grey, black
}
