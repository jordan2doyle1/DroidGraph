package phd.research.enums;

/**
 * @author Jordan Doyle
 */
public enum Type {
    statement, method, callback, listener, lifecycle, control, dummyMethod
}
