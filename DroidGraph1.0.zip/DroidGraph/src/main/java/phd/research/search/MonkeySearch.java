package phd.research.search;

import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import phd.research.core.FrameworkMain;
import phd.research.core.InterfaceManager;
import phd.research.helper.Control;
import phd.research.helper.Pair;
import phd.research.helper.Tuple;
import phd.research.jGraph.Vertex;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * @author Jordan Doyle
 */
public class MonkeySearch extends DepthFirstSearch {

    private static final Logger logger = LoggerFactory.getLogger(MonkeySearch.class);

    public MonkeySearch(Graph<Vertex, DefaultEdge> graph) {
        super(graph);
        this.controlSequence = populateControlSequence();
    }

    @Override
    public void performSearch(boolean output) {
        if(output) {
            System.out.println("Sequence of Controls: ");
            for (Tuple<Integer, String, String> controlTuple : controlSequence) {
                System.out.println("\t" + controlTuple.toString());
            }
            System.out.println();
        }

        super.performSearch(output);
    }

    private List<Tuple<Integer, String, String>> populateControlSequence() {
        List<Tuple<Integer, String, String>> controlsSequence = new ArrayList<>();
        InterfaceManager interfaceManager = InterfaceManager.getInstance();
        List<Pair<Integer, String>> events = getMonkeyEvents(1);

        for (Pair<Integer, String> event : events) {
            if (event.getLeft() == 0) continue;

            String id = event.getRight();
            Control control = interfaceManager.getControl(id);
            int count = event.getLeft() / 2;

            // TODO: Content should not be ignored when null.
            if (control != null) {
                Tuple<Integer, String, String> controlTuple = new Tuple<>(count,
                        control.getClickListener().getDeclaringClass().getName() +
                                control.getClickListener().getName(), String.valueOf(control.getId()));
                controlsSequence.add(controlTuple);
            }
        }

        return controlsSequence;
    }

    @SuppressWarnings("unused")
    private String getJSONString(String fileName) {
        StringBuilder jsonStringBuilder = new StringBuilder();
        String line;

        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
            while((line = bufferedReader.readLine()) != null) {
                jsonStringBuilder.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return jsonStringBuilder.toString();
    }

    @SuppressWarnings("SameParameterValue")
    private List<Pair<Integer, String>> getMonkeyEvents(int testNumber) {
        Properties properties = FrameworkMain.getFrameworkProperties();
        List<Pair<Integer, String>> monkeyEvents = new ArrayList<>();

        if (properties != null) {
            String file = properties.getProperty("RESULTS_LOCATION") + properties.getProperty("PROJECT_NAME") + "/" +
                    testNumber + "/interaction_views";
            String line;

            try {
                BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
                while ((line = bufferedReader.readLine()) != null) {
                    String[] event = line.split(":", 2);
                    if (!event[0].equals("0")) {
                        if (event[1].contains(":")) {
                            event[1] = event[1].split(":")[1];
                        }
                    }
                    monkeyEvents.add(new Pair<>(Integer.parseInt(event[0]), event[1]));
                }
            } catch (IOException e) {
                logger.error("Failure reading monkey events from file \"" + file + "\": " + e.getMessage());
            }
        }

        return monkeyEvents;
    }
}
