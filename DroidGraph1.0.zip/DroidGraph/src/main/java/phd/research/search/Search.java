package phd.research.search;

import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;
import phd.research.core.ClassManager;
import phd.research.enums.State;
import phd.research.enums.Type;
import phd.research.jGraph.Vertex;
import soot.SootClass;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Search controls how to traverse a given graph object representing an Android application. When traversing Android
 * applications it is important to keep a record of the activities in the stack as well as the lifecycle status of the
 * activities, in order to traverse the graph in the same manner it would otherwise be executed on an Android device.
 *
 * @author Jordan Doyle
 */
public class Search {

    protected final Graph<Vertex, DefaultEdge> graph;
    protected final Map<SootClass, State> lifecycleStatus;
    protected final Stack<SootClass> activityStack;

    public Search(Graph<Vertex, DefaultEdge> graph) {
        this.graph = graph;
        this.lifecycleStatus = populateLifecycleMap();
        this.activityStack = new Stack<>();
    }

    /**
     * Calculates the percentage of methods that where traversed during the search.
     *
     * @return percentage value of methods traversed.
     */
    public int calculateMethodCoverage() {
        int noMethods = 0;
        int noMethodsCovered = 0;

        for(Vertex vertex : this.graph.vertexSet()) {
            if (vertex.getType() == Type.method || vertex.getType() == Type.listener || vertex.getType() ==
                    Type.lifecycle) {
                noMethods++;
                if(vertex.hasVisited()) {
                    noMethodsCovered++;
                }
            }
        }

        return Math.round(((float) noMethodsCovered / noMethods) * 100);
    }

    /**
     * Returns a set of methods that where traversed during the search.
     *
     * @return a set of methods that where traversed.
     */
    public Set<Vertex> getCoveredMethods() {
        Set<Vertex> coveredMethods = new HashSet<>();

        for(Vertex vertex : this.graph.vertexSet()) {
            if (vertex.getType() == Type.method || vertex.getType() == Type.listener || vertex.getType() ==
                    Type.lifecycle) {
                if(vertex.hasVisited()) {
                    coveredMethods.add(vertex);
                }
            }
        }

        return coveredMethods;
    }

    /**
     * Returns a set of methods that where not traversed during the search.
     *
     * @return a set of methods that where not traversed.
     */
    public Set<Vertex> getUnCoveredMethods() {
        Set<Vertex> unCoveredMethods = new HashSet<>();

        for(Vertex vertex : this.graph.vertexSet()) {
            if (vertex.getType() == Type.method || vertex.getType() == Type.listener || vertex.getType() ==
                    Type.lifecycle) {
                if(!vertex.hasVisited()) {
                    unCoveredMethods.add(vertex);
                }
            }
        }

        return unCoveredMethods;
    }

    /**
     * Calculates the percentage of interface controls that where traversed during the search.
     *
     * @return percentage value of interface controls traversed.
     */
    public int calculateInterfaceCoverage() {
        int noControls = 0;
        int noControlsCovered = 0;

        for(Vertex vertex : this.graph.vertexSet()) {
            if (vertex.getType() == Type.control) {
                noControls++;
                if(vertex.hasVisited()) {
                    noControlsCovered++;
                }
            }
        }

        return Math.round(((float) noControlsCovered / noControls) * 100);
    }

    /**
     * Returns a set of Interface Controls that where traversed during the search.
     *
     * @return a set of interface controls that where traversed.
     */
    public Set<Vertex> getCoveredInterface() {
        Set<Vertex> coveredVertices = new HashSet<>();

        for(Vertex vertex : this.graph.vertexSet()) {
            if (vertex.getType() == Type.control) {
                if(vertex.hasVisited()) {
                    coveredVertices.add(vertex);
                }
            }
        }

        return coveredVertices;
    }

    /**
     * Returns a set of Interface Controls that where not traversed during the search.
     *
     * @return a set of interface controls that where not traversed.
     */
    public Set<Vertex> getUnCoveredInterface() {
        Set<Vertex> unCoveredVertices = new HashSet<>();

        for(Vertex vertex : this.graph.vertexSet()) {
            if (vertex.getType() == Type.control) {
                if(!vertex.hasVisited()) {
                    unCoveredVertices.add(vertex);
                }
            }
        }

        return unCoveredVertices;
    }

    /**
     * Placeholder method. The search method should be overwritten in the search subclass.
     *
     * @param vertex the vertex instance to search.
     */
    protected void search(Vertex vertex) {
        System.err.println("Search method should be overwritten in the search subclass");
    }

    /**
     * Determines which lifecycle methods should be searched next based on the current lifecycle vertex.
     *
     * @param vertex the current lifecycle vertex.
     */
    protected void updateLifecycle(Vertex vertex) {
        String nextMethodName = null;

        switch(vertex.getSootMethod().getName()) {
            case "onCreate":
                updateLifecycleMap(vertex.getSootClass(), State.created);
                if(!vertex.getSootClass().getName().contains("DialogActivity")) {
                    nextMethodName = "onStart";
                }
                break;
            case "onStart":
                updateLifecycleMap(vertex.getSootClass(), State.started);
                nextMethodName = "onResume";
                break;
            case "onResume":
                updateLifecycleMap(vertex.getSootClass(), State.resumed);
                break;
            case "onRestart":
                updateLifecycleMap(vertex.getSootClass(), State.restarted);
                nextMethodName = "onStart";
                break;
            case "onPause":
                updateLifecycleMap(vertex.getSootClass(), State.paused);
                nextMethodName = "onStop";
                break;
            case "onStop":
                updateLifecycleMap(vertex.getSootClass(), State.stopped);
                if(!activityStack.contains(vertex.getSootClass())) {
                    nextMethodName = "onDestroy";
                }
                break;
            case "onDestroy":
                updateLifecycleMap(vertex.getSootClass(), State.destroyed);
                break;
            case "onTouchEvent":
                break;
            default:
                System.err.println("Lifecycle: Unrecognised Lifecycle Method!");
                break;
        }

        if(nextMethodName != null) {
            Vertex nextVertex = getMethodVertex(vertex.getSootClass(), nextMethodName, Type.lifecycle);
            search(nextVertex);
        }
    }

    /**
     * Simulates pressing an interface control in the search. Finds the interface control vertex in the graph and starts
     * a local search with that vertex as the root.
     *
     * @param sootClass the class the interface control belongs to.
     * @param controlID the id of the interface control.
     */
    protected void pressInterfaceControl(SootClass sootClass, String controlID) {
        Vertex interfaceVertex = getInterfaceControl(sootClass, controlID);
        search(interfaceVertex);
    }

    /**
     * Simulates launching an Activity in the search. Simply adds the activity to the top of the activity stack.
     *
     * @param sootClass SootClass instance for the activity to launch.
     */
    protected void launchActivity(SootClass sootClass) {
        addStackActivity(sootClass);
    }

    /**
     * Simulates pressing the back button in the search. Simply pops the top activity from the stack.
     */
    protected void pressBack() {
        popStackActivity();
    }

    /**
     * Checks if the given Vertex instance is an intent statement (An intent is used to call and launch another
     * activity). If it is then the activity is launched in the search and therefore added to the activity stack.
     *
     * @param vertex the Vertex instance to check for the intent call.
     */
    protected void checkForIntentAndStart(Vertex vertex) {
        if(vertex.getLabel().contains("Intent") && vertex.getLabel().contains("specialinvoke")) {
            Pattern pattern = Pattern.compile("\"L([\\w+/]+);\"");
            Matcher matcher = pattern.matcher(vertex.getLabel());
            if(matcher.find()) {
                String className = matcher.group(1).replace("/", ".");
                SootClass sootClass = ClassManager.getInstance().getEntryPoint(className);
                launchActivity(sootClass);
            }
        }
    }

    /**
     * Checks if the given Vertex instance is a call statement to the method finish(). If it is then the activity is
     * popped from the activity stack. The finish() method indicates the activity will be closed and therefore removed
     * from the activity stack within the Android Framework.
     *
     * @param vertex the Vertex instance to check for the finish method call.
     */
    protected void checkForActivityFinish(Vertex vertex) {
        if(vertex.getLabel().contains("virtualinvoke") && vertex.getLabel().contains("void finish()")) {
            popStackActivity();
        }
    }

    /**
     * Resets local visit status in all graph vertices. This enables repeat visits in the graph when needed.
     */
    protected void resetLocalVisitStatus() {
        for (Vertex vertex : graph.vertexSet()) {
            vertex.localVisitReset();
        }
    }

    /**
     * Adds an activity to the activity stack. Once an activity is added to the stack the lifecycle status of the
     * previous activity and the new activity is checked and updated accordingly.
     *
     * @param newActivity the activity to add to the stack.
     */
    private void addStackActivity(SootClass newActivity) {
        if(!this.activityStack.isEmpty()) {
            SootClass previousActivity = activityStack.peek();
            Vertex pauseVertex = getMethodVertex(previousActivity, "onPause", Type.lifecycle);
            search(pauseVertex);
        }

        activityStack.add(newActivity);

        if(lifecycleStatus.containsKey(newActivity)) {
            String nextMethodName = null;
            State status = lifecycleStatus.get(newActivity);
            switch(status) {
                case paused:
                    nextMethodName = "onResume";
                    break;
                case stopped:
                    nextMethodName = "onRestart";
                    break;
                case destroyed:
                    Vertex initVertex = getMethodVertex(newActivity, "<init>", Type.method);
                    search(initVertex);
                    nextMethodName = "onCreate";
                    break;
                default:
                    System.err.println("Add Stack Activity: Unknown Activity Lifecycle State");
                    break;
            }

            if(nextMethodName != null) {
                Vertex nextVertex = getMethodVertex(newActivity, nextMethodName, Type.lifecycle);
                search(nextVertex);
            }
        } else {
            System.err.println("Activity not in Lifecycle Status Mapping!!!");
        }
    }

    /**
     * Removes the top activity from the stack. Once an activity is removed from the stack the lifecycle status of the
     * previous activity and the new top activity is checked and updated accordingly.
     */
    private void popStackActivity() {
        SootClass previousActivity = activityStack.pop();
        if(previousActivity.getName().contains("DialogActivity")) {
            updateLifecycleMap(previousActivity, State.destroyed);
            Vertex onTouchVertex = getMethodVertex(previousActivity, "onTouchEvent", Type.lifecycle);
            if(onTouchVertex != null) onTouchVertex.visit();
        } else {
            Vertex pauseVertex = getMethodVertex(previousActivity, "onPause", Type.lifecycle);
            search(pauseVertex);
        }

        if(!this.activityStack.isEmpty()) {
            SootClass newActivity = activityStack.peek();

            if (lifecycleStatus.containsKey(newActivity)) {
                String nextMethodName = null;
                State status = lifecycleStatus.get(newActivity);
                switch (status) {
                    case paused:
                        nextMethodName = "onResume";
                        break;
                    case stopped:
                        nextMethodName = "onRestart";
                        break;
                    case destroyed:
                        Vertex initVertex = getMethodVertex(newActivity, "<init>", Type.method);
                        search(initVertex);
                        nextMethodName = "onCreate";
                        break;
                    default:
                        System.err.println("Add Stack Activity: Unknown Activity Lifecycle State");
                        break;
                }

                if(nextMethodName != null) {
                    Vertex nextVertex = getMethodVertex(newActivity, nextMethodName, Type.lifecycle);
                    search(nextVertex);
                }
            } else {
                System.err.println("New Activity not in Lifecycle Status Mapping!!!");
            }
        }

    }

    /**
     * Retrieves a method Vertex from the graph with the given SootClass, method name and method type.
     *
     * @param sootClass     the class the method belongs to.
     * @param methodName    the name of the method to search for.
     * @param methodType    the type of method to search for.
     *
     * @return a Vertex instance with the given method name.
     */
    private Vertex getMethodVertex(SootClass sootClass, String methodName, Type methodType) {
        for (Vertex vertex : graph.vertexSet()) {
            if(vertex.getType() == methodType) {
                if (vertex.getSootClass() == sootClass && vertex.getSootMethod().getName().equals(methodName)) {
                    return vertex;
                }
            }
        }
        return null;
    }

    /**
     * Retrieves an Interface Control Vertex from the graph with the given SootClass and control label.
     *
     * @param sootClass     the class the interface control belongs to.
     * @param controlLabel  the interface control label to search for.
     *
     * @return a Vertex instance with the given control label.
     */
    private Vertex getInterfaceControl(SootClass sootClass, String controlLabel) {
        for (Vertex vertex : graph.vertexSet()) {
            if(vertex.getType() == Type.control) {
                if (vertex.getSootClass() == sootClass && vertex.getLabel().equals(controlLabel)) {
                    return vertex;
                }
            }
        }
        return null;
    }

    /**
     * Update the status of the given activity with the given status in the lifecycle status map.
     *
     * @param activity  the activity to update in the lifecycle status map.
     * @param status    the update status to apply to the activity in the lifecycle status map.
     */
    private void updateLifecycleMap(SootClass activity, State status) {
        if(lifecycleStatus.containsKey(activity)) {
            lifecycleStatus.put(activity, status);
        } else {
            System.err.println("Activity not in lifecycle status Mapping!!!");
        }
    }

    /**
     * Populates the lifecycle state map with all application activities and there initial state. At the beginning all
     * activities are in the destroyed state.
     *
     * @return Returns an instance of Map where the keys are the activity classes from the search application and the
     * values are the state of those activities (i.e. Destroyed)
     */
    private Map<SootClass, State> populateLifecycleMap() {
        Map<SootClass, State> lifecycleMap = new HashMap<>();

        for (SootClass entryClass : ClassManager.getInstance().getEntryPoints()) {
            lifecycleMap.put(entryClass, State.destroyed);
        }

        return lifecycleMap;
    }
}
