package phd.research.search;

import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;
import phd.research.core.ClassManager;
import phd.research.enums.State;
import phd.research.helper.Tuple;
import phd.research.jGraph.Vertex;
import soot.SootClass;

import java.util.*;

/**
 * Depth First Search traverses a given graph object representing an Android application in a depth first manner. It
 * extends {@link Search} to provide activity stack and lifecycle controls during the search.
 *
 * @author Jordan Doyle
 */
public class DepthFirstSearch extends Search {

    private final List<Tuple<Integer, Integer, Integer>> coverageResults;

    protected List<Tuple<Integer, String, String>> controlSequence = new ArrayList<>(Arrays.asList(
            new Tuple<>(2,"com.example.android.lifecycle.ActivityA$1", "2130968581"),       //StartB
            new Tuple<>(3,"com.example.android.lifecycle.ActivityB$1", "2130968580"),       //StartA
            new Tuple<>(4,"com.example.android.lifecycle.ActivityA$2", "2130968582"),       //StartC
            new Tuple<>(5,"com.example.android.lifecycle.ActivityC", "2130968580"),         //StartA
            new Tuple<>(6,"com.example.android.lifecycle.ActivityA$4", "2130968576"),       //FinishA
            new Tuple<>(7,"com.example.android.lifecycle.ActivityC", "2130968581"),         //StartB
            new Tuple<>(8,"com.example.android.lifecycle.ActivityB$2", "2130968582"),       //StartC
            new Tuple<>(9,"com.example.android.lifecycle.ActivityC", "2130968578"),         //FinishC
            new Tuple<>(10,"com.example.android.lifecycle.ActivityB$4", "2130968577"),      //FinishB
            new Tuple<>(11,"com.example.android.lifecycle.ActivityC", "2130968583"),        //Dialog
            new Tuple<>(12, "com.example.android.lifecycle.DialogActivity", "2130968579"),  //FinDialog
            new Tuple<>(13, "", "BACK"),
            new Tuple<>(14, "com.example.android.lifecycle.ActivityA$3", "2130968583"),     //Dialog
            new Tuple<>(15, "", "BACK"),
            new Tuple<>(16, "", "BACK"),
            new Tuple<>(17, "com.example.android.lifecycle.ActivityB$3", "2130968583"),     //Dialog
            new Tuple<>(18, "", "BACK"),
            new Tuple<>(19, "", "BACK"),
            new Tuple<>(20, "", "BACK")
    ));

    public DepthFirstSearch(Graph<Vertex, DefaultEdge> graph) {
        super(graph);
        this.coverageResults = new ArrayList<>();
    }

    @SuppressWarnings("unused")
    public DepthFirstSearch(Graph<Vertex, DefaultEdge> graph, List<Tuple<Integer, String, String>> controlSequence) {
        super(graph);
        this.controlSequence = controlSequence;
        this.coverageResults = new ArrayList<>();
    }

    /**
     * Starts a Depth First Search of the graph. If output is true then the search will print the activity stack,
     * lifecycle status map and the coverage stats to the console throughout the search, otherwise it will output
     * nothing.
     *
     * @param output if true, search progress is printed to the console throughout search.
     */
    public void performSearch(boolean output) {
        if(output) System.out.println("Launching App...");
        SootClass launchingActivity = (SootClass) ClassManager.getInstance().getLaunchActivities().toArray()[0];
        launchActivity(launchingActivity);
        coverageResults.add(new Tuple<>(1, calculateInterfaceCoverage(), calculateMethodCoverage()));
        if(output) printsSearchUpdate();

        for(Tuple<Integer, String, String> control : controlSequence) {
            if(control.getMiddle().equals("") && control.getRight().equals("BACK")) {
                if(output) System.out.println("Pressing Back Button...");
                pressBack();
            } else {
                SootClass sootClass = ClassManager.getInstance().getEntryPoint(control.getMiddle());
                if(output) System.out.println("Pressing Interface Control: " + control.getRight() + "...");
                pressInterfaceControl(sootClass, control.getRight());
            }

            coverageResults.add(new Tuple<>(control.getLeft(), calculateInterfaceCoverage(), calculateMethodCoverage()));
            resetLocalVisitStatus();
            if(output) printsSearchUpdate();
        }
    }

    /**
     * Returns the Interface and Method Coverage results of the Depth First Search in a list of tuples where a tuple is
     * (Interaction Number, Percentage Interface Coverage, Percentage Method Coverage).
     *
     * @return a list of tuples containing the DFS coverage results.
     */
    public List<Tuple<Integer, Integer, Integer>> getCoverageResults() {
        return this.coverageResults;
    }

    /**
     * Recursively traverses each vertex using the given vertex as the root using a Depth First Search (DFS) algorithm.
     *
     * @param vertex the vertex instance to search.
     */
    @Override
    protected void search(Vertex vertex) {
        vertex.visit();
        vertex.localVisit();

        for(DefaultEdge edge : graph.outgoingEdgesOf(vertex)) {
            Vertex targetVertex = graph.getEdgeTarget(edge);
            if(!targetVertex.hasLocalVisit()) {
                search(targetVertex);
            }
        }

        switch(vertex.getType()) {
            case statement:
                checkForIntentAndStart(vertex);
                checkForActivityFinish(vertex);
                break;
            case lifecycle:
                updateLifecycle(vertex);
                break;
        }
    }

    /**
     * Prints the current activity stack, lifecycle status map and coverage stats to the console.
     */
    private void printsSearchUpdate() {
        printActivityStack();
        printLifecycleStatus();
        printCoverageStats();
    }

    /**
     * Prints the lifecycle status mapping to the console.
     */
    private void printLifecycleStatus() {
        System.out.println("Lifecycle Status: ");
        for (Map.Entry<SootClass, State> entry : lifecycleStatus.entrySet()) {
            System.out.println("\t" + entry.getKey() + ": " + entry.getValue());
        }
    }

    /**
     * Prints the activity stack to the console.
     */
    private void printActivityStack() {
        System.out.println("Activity Stack: ");
        if(activityStack.isEmpty()) {
            System.out.println("\tEmpty");
        } else {
            Object[] stackArray = activityStack.toArray();
            for (Object obj : stackArray) {
                SootClass currentClass = (SootClass) obj;
                System.out.println("\t" + currentClass.getName());
            }
        }
    }

    /**
     * Prints the coverage stats to the console.
     */
    private void printCoverageStats() {
        System.out.println("Coverage Stats: ");
        System.out.println("\tInterface Coverage: " + calculateInterfaceCoverage());
        System.out.println("\tMethod Coverage: " + calculateMethodCoverage());
    }
}
