package phd.research.search;

import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;
import phd.research.core.ClassManager;
import phd.research.enums.State;
import phd.research.helper.Tuple;
import phd.research.jGraph.Vertex;
import soot.SootClass;

import java.util.*;

/**
 * Breadth First Search traverses a given graph object representing an Android application in a breadth first manner. It
 * extends {@link Search} to provide activity stack and lifecycle controls during the search.
 *
 * @author Jordan Doyle
 */
public class BreadthFirstSearch extends Search {

    private List<Tuple<Integer, String, String>> controlSequence = new ArrayList<>(Arrays.asList(
            new Tuple<>(0, "Placeholder", "Placeholder"),
            new Tuple<>(0, "Placeholder", "Placeholder")
    ));
    private List<Tuple<Integer, Integer, Integer>> coverageResults;

    public BreadthFirstSearch(Graph<Vertex, DefaultEdge> graph) {
        super(graph);
        coverageResults = new ArrayList<>();
    }

    @SuppressWarnings("unused")
    public BreadthFirstSearch(Graph<Vertex, DefaultEdge> graph, List<Tuple<Integer, String, String>> controlSequence) {
        super(graph);
        this.controlSequence = controlSequence;
    }

    /**
     * Starts a Breadth First Search of the graph. If output is true then the search will print the activity stack,
     * lifecycle status map and the coverage stats to the console throughout the search, otherwise it will output
     * nothing.
     *
     * @param output if true, search progress is printed to the console throughout search.
     */
    public void performSearch(boolean output) {
        if(output) System.out.println("Launching App...");
        SootClass launchingActivity = (SootClass) ClassManager.getInstance().getLaunchActivities().toArray()[0];
        launchActivity(launchingActivity);
        coverageResults.add(new Tuple<>(1, calculateInterfaceCoverage(), calculateMethodCoverage()));
        if(output) printsSearchUpdate();

        for(Tuple<Integer, String, String> control : controlSequence) {
            if(control.getMiddle().equals("") && control.getRight().equals("BACK")) {
                if(output) System.out.println("Pressing Back Button...");
                pressBack();
            } else {
                SootClass sootClass = ClassManager.getInstance().getEntryPoint(control.getMiddle());
                if(output) System.out.println("Pressing Interface Control: " + control.getRight() + "...");
                pressInterfaceControl(sootClass, control.getRight());
            }

            coverageResults.add(new Tuple<>(control.getLeft(), calculateInterfaceCoverage(), calculateMethodCoverage()));
            resetLocalVisitStatus();
            if(output) printsSearchUpdate();
        }
    }

    /**
     * Returns the Interface and Method Coverage results of the Breadth First Search in a list of tuples where a tuple is
     * (Interaction Number, Percentage Interface Coverage, Percentage Method Coverage).
     *
     * @return a list of tuples containing the BFS coverage results.
     */
    public List<Tuple<Integer, Integer, Integer>> getCoverageResults() {
        return this.coverageResults;
    }

    /**
     * Recursively traverses each vertex using the given vertex as the root using a Breadth First Search (BFS) algorithm
     *
     * @param vertex the vertex instance to search.
     */
    @Override
    protected void search(Vertex vertex) {
        System.err.println("BFS Search Currently Not Implemented!!!");
    }

    /**
     * Prints the current activity stack, lifecycle status map and coverage stats to the console.
     */
    private void printsSearchUpdate() {
        printActivityStack();
        printLifecycleStatus();
        printCoverageStats();
    }

    /**
     * Prints the lifecycle status mapping to the console.
     */
    private void printLifecycleStatus() {
        System.out.println("Lifecycle Status: ");
        for (Map.Entry<SootClass, State> entry : lifecycleStatus.entrySet()) {
            System.out.println("\t" + entry.getKey() + ": " + entry.getValue());
        }
    }

    /**
     * Prints the activity stack to the console.
     */
    private void printActivityStack() {
        System.out.println("Activity Stack: ");
        if(activityStack.isEmpty()) {
            System.out.println("\tEmpty");
        } else {
            Object[] stackArray = activityStack.toArray();
            for (Object obj : stackArray) {
                SootClass currentClass = (SootClass) obj;
                System.out.println("\t" + currentClass.getName());
            }
        }
    }

    /**
     * Prints the coverage stats to the console.
     */
    private void printCoverageStats() {
        System.out.println("Coverage Stats: ");
        System.out.println("\tInterface Coverage: " + calculateInterfaceCoverage());
        System.out.println("\tMethod Coverage: " + calculateMethodCoverage());
    }
}
